import 'package:flutter/material.dart';

import '../../models/item_liste.dart';
import '../../services/firestore_listes_service.dart';
import '../../services/seed_service.dart';

/// Traduit un code de secteur brut (venant du fichier Excel) en libellé
/// lisible par l'utilisateur. Règle : 0 = Public, 1 = Privé, 2 = Libre.
/// Si la valeur n'est pas un code connu, on l'affiche telle quelle
/// (cas où l'utilisateur aurait déjà tapé "Public" directement, par ex.).
String libelleSecteur(String valeurBrute) {
  switch (valeurBrute.trim()) {
    case '0':
      return 'Public';
    case '1':
      return 'Privé';
    case '2':
      return 'Libre';
    default:
      return valeurBrute;
  }
}

/// Écran générique de gestion d'une liste de référence, affichée en
/// TABLEAU (DataTable) avec une barre de recherche.
///
/// Réutilisé pour : établissements, écoles d'origine (CEPE/BEPC), CEG
/// d'accueil, lycée d'accueil, langues, sports collectifs/individuels.
class GestionListeScreen extends StatefulWidget {
  final String titre;
  final String typeListe;
  final List<String> nomsChamps;

  const GestionListeScreen({
    super.key,
    required this.titre,
    required this.typeListe,
    required this.nomsChamps,
  });

  @override
  State<GestionListeScreen> createState() => _GestionListeScreenState();
}

class _GestionListeScreenState extends State<GestionListeScreen> {
  List<ItemListe> _items = [];
  String _recherche = '';
  String? _zapFiltre;

  @override
  void initState() {
    super.initState();
    _rafraichir();
  }

  Future<void> _rafraichir() async {
    try {
      await SeedService.assurerType(widget.typeListe);
    } catch (_) {
      // Pas admin / pas de connexion : on affiche ce qui est en ligne.
    }
    final items = await FirestoreListesService.listerItems(widget.typeListe);
    if (!mounted) return;
    setState(() => _items = items);
  }

  List<ItemListe> get _itemsFiltres {
    final q = _recherche.toLowerCase();
    return _items.where((item) {
      final zapOk = _zapFiltre == null || item.champs['zap'] == _zapFiltre;
      final texteOk =
          q.isEmpty ||
          item.champs.values.any((v) => v.toLowerCase().contains(q));
      return zapOk && texteOk;
    }).toList();
  }

  /// Valeur affichée dans le tableau : applique la traduction secteur si
  /// le champ s'appelle 'secteur', sinon affiche la valeur brute.
  String _valeurAffichee(String champ, String valeurBrute) {
    if (champ == 'secteur') return libelleSecteur(valeurBrute);
    return valeurBrute;
  }

  IconData _iconePourChamp(String champ) {
    switch (champ) {
      case 'code':
        return Icons.qr_code;
      case 'libelle':
      case 'nom':
        return Icons.label;
      case 'secteur':
        return Icons.apartment;
      case 'codecorrection':
        return Icons.link;
      default:
        return Icons.edit_note;
    }
  }

  Future<void> _ouvrirFormulaire({ItemListe? existant}) async {
    final controllers = {
      for (final champ in widget.nomsChamps)
        champ: TextEditingController(text: existant?.champs[champ] ?? ''),
    };

    final resultat = await showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        insetPadding: const EdgeInsets.all(20),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // --- Bandeau coloré en haut de la boîte de dialogue ---
              Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(18),
                  ),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: existant == null
                        ? [Colors.green.shade600, Colors.teal.shade600]
                        : [Colors.blue.shade600, Colors.indigo.shade600],
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(
                        existant == null ? Icons.add : Icons.edit,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        existant == null
                            ? 'Ajouter — ${widget.titre}'
                            : 'Modifier — ${widget.titre}',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 17,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      for (final champ in widget.nomsChamps) ...[
                        if (champ == 'secteur')
                          DropdownButtonFormField<String>(
                            initialValue: controllers[champ]!.text.isEmpty
                                ? null
                                : controllers[champ]!.text,
                            decoration: InputDecoration(
                              labelText: 'Secteur',
                              prefixIcon: Icon(_iconePourChamp(champ)),
                              border: const OutlineInputBorder(),
                              filled: true,
                              fillColor: Colors.grey.shade50,
                            ),
                            items: const [
                              DropdownMenuItem(
                                value: '0',
                                child: Text('Public'),
                              ),
                              DropdownMenuItem(
                                value: '1',
                                child: Text('Privé'),
                              ),
                              DropdownMenuItem(
                                value: '2',
                                child: Text('Libre'),
                              ),
                            ],
                            onChanged: (val) =>
                                controllers[champ]!.text = val ?? '',
                          )
                        else
                          TextField(
                            controller: controllers[champ],
                            decoration: InputDecoration(
                              labelText:
                                  champ[0].toUpperCase() + champ.substring(1),
                              prefixIcon: Icon(_iconePourChamp(champ)),
                              border: const OutlineInputBorder(),
                              filled: true,
                              fillColor: Colors.grey.shade50,
                            ),
                          ),
                        const SizedBox(height: 14),
                      ],
                      const SizedBox(height: 4),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          TextButton(
                            onPressed: () => Navigator.of(ctx).pop(false),
                            child: const Text('Annuler'),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton.icon(
                            onPressed: () => Navigator.of(ctx).pop(true),
                            icon: const Icon(Icons.check, size: 18),
                            label: const Text('Enregistrer'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 18,
                                vertical: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );

    if (resultat != true) return;

    final champsSaisis = {
      for (final champ in widget.nomsChamps) champ: controllers[champ]!.text,
    };

    final item = ItemListe(
      id:
          existant?.id ??
          '${widget.typeListe}_${DateTime.now().millisecondsSinceEpoch}',
      typeListe: widget.typeListe,
      champs: champsSaisis,
    );

    if (existant == null) {
      await FirestoreListesService.insererItemListe(item);
    } else {
      await FirestoreListesService.modifierItemListe(item);
    }
    await _rafraichir();
  }

  Future<void> _supprimer(ItemListe item) async {
    await FirestoreListesService.supprimerItemListe(item.id);
    await _rafraichir();
  }

  @override
  Widget build(BuildContext context) {
    final items = _itemsFiltres;

    return Scaffold(
      backgroundColor: const Color(0xFFF4F6F9),
      appBar: AppBar(title: Text(widget.titre)),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Colors.green,
        onPressed: () => _ouvrirFormulaire(),
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('Ajouter', style: TextStyle(color: Colors.white)),
      ),
      body: Column(
        children: [
          if (widget.typeListe == 'etablissement')
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
              child: DropdownButtonFormField<String>(
                value: _zapFiltre,
                decoration: const InputDecoration(
                  labelText: 'Filtrer par ZAP',
                  border: OutlineInputBorder(),
                ),
                items: <DropdownMenuItem<String>>[
                  const DropdownMenuItem<String>(
                    value: null,
                    child: Text('Toutes les ZAP'),
                  ),
                  ...(_items
                          .map((e) => e.champs['zap'])
                          .whereType<String>()
                          .where((z) => z.isNotEmpty)
                          .toSet()
                          .toList()
                        ..sort())
                      .map(
                        (z) =>
                            DropdownMenuItem<String>(value: z, child: Text(z)),
                      ),
                ],
                onChanged: (z) => setState(() => _zapFiltre = z),
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'Rechercher...',
                border: OutlineInputBorder(),
                isDense: true,
              ),
              onChanged: (val) => setState(() => _recherche = val),
            ),
          ),
          Expanded(
            child: items.isEmpty
                ? const Center(child: Text('Aucun résultat'))
                : Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Card(
                      elevation: 1,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: SingleChildScrollView(
                          child: DataTable(
                            headingRowColor: WidgetStateProperty.all(
                              Colors.green.shade50,
                            ),
                            columns: [
                              for (final champ in widget.nomsChamps)
                                DataColumn(label: Text(champ.toUpperCase())),
                              const DataColumn(label: Text('ACTIONS')),
                            ],
                            rows: [
                              for (final item in items)
                                DataRow(
                                  cells: [
                                    for (final champ in widget.nomsChamps)
                                      DataCell(
                                        Text(
                                          _valeurAffichee(
                                            champ,
                                            item.champs[champ] ?? '',
                                          ),
                                        ),
                                      ),
                                    DataCell(
                                      Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          IconButton(
                                            icon: const Icon(
                                              Icons.edit,
                                              size: 20,
                                              color: Colors.blue,
                                            ),
                                            onPressed: () => _ouvrirFormulaire(
                                              existant: item,
                                            ),
                                          ),
                                          IconButton(
                                            icon: const Icon(
                                              Icons.delete,
                                              size: 20,
                                              color: Colors.red,
                                            ),
                                            onPressed: () => _supprimer(item),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
