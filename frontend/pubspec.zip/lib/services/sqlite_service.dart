import 'dart:io' show Platform;

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import '../models/candidat_cepe.dart';
import '../models/candidat_bepc.dart';
import '../models/membre_previsionnel.dart';
import '../models/salle.dart';
import '../models/attribution_salle.dart';
import '../models/periode_saisie.dart';
import '../models/item_liste.dart';
import '../models/enseignant.dart';
import '../models/chat_message.dart';
import '../models/quota_membre.dart';

/// Service d'accès à la base de données locale (SQLite).
///
/// Contient DEUX tables séparées, comme demandé, car CEPE et BEPC sont deux
/// examens différents avec des attributs propres à chacun :
///   - candidat_cepe  (groupe A/B/C, codeCegAccueil)
///   - candidat_bepc  (groupe I/II/III, codeLyceeAccueil, neeVert,
///                     numeroInscriptionAnneePrecedente)
///
/// Ce service sert de base "offline" : les données restent disponibles même
/// sans connexion. La synchronisation vers Firebase se fait séparément
/// (voir sync_service.dart, à faire dans une prochaine étape).
class SqliteService {
  SqliteService._internal();
  static final SqliteService instance = SqliteService._internal();

  static Database? _db;

  static const String tableCandidatCepe = 'candidat_cepe';
  static const String tableCandidatBepc = 'candidat_bepc';
  static const String tableMembrePrevisionnel = 'membre_previsionnel';
  static const String tableSalle = 'salle';
  static const String tableItemListe = 'item_liste';
  static const String tableEnseignant = 'enseignant';
  static const String tableQuotaMembre = 'quota_membre';
  static const String tableAttributionSalle = 'attribution_salle';
  static const String tablePeriodeSaisie = 'periode_saisie';
  static const String tableChatMessage = 'chat_message';
  static const String tableParametreSession = 'parametre_session';

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDatabase();
    return _db!;
  }

  /// Supprime complètement la base locale et la recrée vide (les tables
  /// sont recréées automatiquement via onCreate). Utile en développement
  /// quand on modifie la structure des tables (ex: ajout d'une colonne) :
  /// sans ça, SQLite garde l'ancienne structure et le nouveau champ
  /// n'apparaît jamais tant qu'on ne supprime pas manuellement le fichier.
  ///
  /// ⚠️ Supprime TOUTES les données locales (candidats, membres, listes...).
  /// À utiliser seulement en phase de développement/test, jamais en prod.
  Future<void> reinitialiserBase() async {
    if (!kIsWeb &&
        (Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    }

    if (_db != null) {
      await _db!.close();
      _db = null;
    }

    final String path = join(await getDatabasesPath(), 'gestion_examens.db');
    await databaseFactory.deleteDatabase(path);

    // Force la recréation immédiate (sinon elle ne se recrée qu'au
    // prochain accès à `database`).
    _db = await _initDatabase();
  }

  Future<Database> _initDatabase() async {
    // Sur Windows/Linux/macOS (bureau), sqflite standard ne fonctionne pas :
    // il faut basculer sur le moteur FFI, qui simule SQLite en natif.
    // Sur Android/iOS, on garde le moteur sqflite normal (ne rien changer).
    if (!kIsWeb &&
        (Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    }

    final String path = join(await getDatabasesPath(), 'gestion_examens.db');
    return openDatabase(
      path,
      version: 7,
      onCreate: _onCreate,
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute('ALTER TABLE $tableEnseignant ADD COLUMN cin TEXT');
          await db.execute('ALTER TABLE $tableEnseignant ADD COLUMN sexe TEXT');
          await db.execute(
            'ALTER TABLE $tableCandidatCepe ADD COLUMN codeCentreCorrection TEXT',
          );
          await db.execute(
            'ALTER TABLE $tableCandidatBepc ADD COLUMN codeCentreCorrection TEXT',
          );
        }
        if (oldVersion < 3) {
          await db.execute(
            'ALTER TABLE $tableCandidatCepe ADD COLUMN neeVert INTEGER NOT NULL DEFAULT 0',
          );
        }
        if (oldVersion < 4) {
          // Ces deux tables (quota_membre, chat_message) avaient été
          // ajoutées uniquement dans _onCreate, donc jamais créées sur les
          // appareils qui avaient déjà une base en version 3. C'était la
          // cause du chat qui restait bloqué en chargement à l'infini
          // (la requête SQL plantait car la table n'existait pas).
          await db.execute('''
            CREATE TABLE IF NOT EXISTS $tableQuotaMembre (
              id TEXT PRIMARY KEY,
              typeExamen TEXT NOT NULL,
              role TEXT NOT NULL,
              quantite INTEGER NOT NULL
            )
          ''');
          await db.execute('''
            CREATE TABLE IF NOT EXISTS $tableChatMessage (
              id TEXT PRIMARY KEY,
              codeEtab TEXT NOT NULL,
              expediteur TEXT NOT NULL,
              texte TEXT NOT NULL,
              horodatage TEXT NOT NULL,
              lu INTEGER NOT NULL DEFAULT 0
            )
          ''');
        }
        if (oldVersion < 5) {
          // Ajout de la photo jointe et du marqueur "modifié" sur les
          // messages du chat (édition/suppression/photo demandées).
          final colonnes = await db.rawQuery(
            "PRAGMA table_info($tableChatMessage)",
          );
          final noms = colonnes.map((c) => c['name'] as String).toSet();
          if (!noms.contains('photoPath')) {
            await db.execute(
              'ALTER TABLE $tableChatMessage ADD COLUMN photoPath TEXT',
            );
          }
          if (!noms.contains('modifie')) {
            await db.execute(
              'ALTER TABLE $tableChatMessage ADD COLUMN modifie INTEGER NOT NULL DEFAULT 0',
            );
          }
        }
        if (oldVersion < 6) {
          // Séparation stricte CEPE/BEPC pour les membres et les quotas
          // (même établissement, mais examens différents), + nouvelle
          // table pour attribuer des places de salle par établissement.
          final colonnesMembre = await db.rawQuery(
            "PRAGMA table_info($tableMembrePrevisionnel)",
          );
          if (!colonnesMembre.any((c) => c['name'] == 'typeExamen')) {
            await db.execute(
              "ALTER TABLE $tableMembrePrevisionnel ADD COLUMN typeExamen TEXT NOT NULL DEFAULT 'CEPE'",
            );
          }
          final colonnesQuota = await db.rawQuery(
            "PRAGMA table_info($tableQuotaMembre)",
          );
          if (!colonnesQuota.any((c) => c['name'] == 'typeExamen')) {
            await db.execute(
              "ALTER TABLE $tableQuotaMembre ADD COLUMN typeExamen TEXT NOT NULL DEFAULT 'CEPE'",
            );
          }
          await db.execute('''
            CREATE TABLE IF NOT EXISTS $tableAttributionSalle (
              id TEXT PRIMARY KEY,
              codeSalle TEXT NOT NULL,
              codeEtab TEXT NOT NULL,
              nombreCandidats INTEGER NOT NULL
            )
          ''');
        }
        if (oldVersion < 7) {
          // Période de saisie autorisée (date début/fin + description),
          // définie par l'admin, pour bloquer la saisie des candidats hors
          // de cette fenêtre et remplacer les messages individuels.
          await db.execute('''
            CREATE TABLE IF NOT EXISTS $tablePeriodeSaisie (
              id TEXT PRIMARY KEY,
              dateDebut TEXT NOT NULL,
              dateFin TEXT NOT NULL,
              description TEXT NOT NULL,
              definiLe TEXT NOT NULL
            )
          ''');
        }
      },
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    // --- Table CEPE ---
    await db.execute('''
      CREATE TABLE $tableCandidatCepe (
        codeCandidat TEXT PRIMARY KEY,
        numero INTEGER NOT NULL,
        nom TEXT NOT NULL,
        prenom TEXT NOT NULL,
        lieuNaissance TEXT NOT NULL,
        adresseActuelle TEXT NOT NULL,
        dateNaissance TEXT NOT NULL,
        sexe TEXT NOT NULL,
        handicap INTEGER NOT NULL DEFAULT 0,
        typeHandicap TEXT,
        nomPere TEXT,
        nomMere TEXT NOT NULL,
        groupe TEXT NOT NULL,
        langue TEXT,
        neeVert INTEGER NOT NULL DEFAULT 0,
        codeEcoleOrigine TEXT NOT NULL,
        codeCegAccueil TEXT,
        codeEtab TEXT NOT NULL,
        codeCentreEcrit TEXT,
        codeCentreCorrection TEXT,
        numeroSalle TEXT,
        eps INTEGER NOT NULL DEFAULT 0,
        epreuveObligatoire TEXT,
        epreuveAuChoix TEXT,
        epreuveCollective TEXT,
        photo TEXT NOT NULL,
        etatCandidat TEXT NOT NULL,
        anneeSession INTEGER NOT NULL
      )
    ''');

    // --- Table BEPC ---
    await db.execute('''
      CREATE TABLE $tableCandidatBepc (
        codeCandidat TEXT PRIMARY KEY,
        numero INTEGER NOT NULL,
        nom TEXT NOT NULL,
        prenom TEXT NOT NULL,
        lieuNaissance TEXT NOT NULL,
        adresseActuelle TEXT NOT NULL,
        dateNaissance TEXT NOT NULL,
        sexe TEXT NOT NULL,
        handicap INTEGER NOT NULL DEFAULT 0,
        typeHandicap TEXT,
        nomPere TEXT,
        nomMere TEXT NOT NULL,
        groupe TEXT NOT NULL,
        langue TEXT,
        numeroInscriptionAnneePrecedente TEXT,
        neeVert INTEGER NOT NULL DEFAULT 0,
        codeEcoleOrigine TEXT NOT NULL,
        codeLyceeAccueil TEXT,
        codeEtab TEXT NOT NULL,
        codeCentreEcrit TEXT,
        codeCentreCorrection TEXT,
        numeroSalle TEXT,
        eps INTEGER NOT NULL DEFAULT 0,
        epreuveObligatoire TEXT,
        epreuveAuChoix TEXT,
        epreuveCollective TEXT,
        photo TEXT NOT NULL,
        etatCandidat TEXT NOT NULL,
        anneeSession INTEGER NOT NULL
      )
    ''');

    // --- Table Membre prévisionnel (jury, correcteur, chef de centre, sécurité) ---
    await db.execute('''
      CREATE TABLE $tableMembrePrevisionnel (
        codeMembre TEXT PRIMARY KEY,
        matriculeEnseignant TEXT NOT NULL,
        role TEXT NOT NULL,
        etat TEXT NOT NULL,
        photoCinRecto TEXT,
        photoCinVerso TEXT,
        codeCentreEcrit TEXT,
        codeCentreCorrection TEXT,
        anneeSession INTEGER NOT NULL,
        typeExamen TEXT NOT NULL DEFAULT 'CEPE'
      )
    ''');

    // --- Table Salle (saisie manuelle par centre) ---
    await db.execute('''
      CREATE TABLE $tableSalle (
        id TEXT PRIMARY KEY,
        codeCentre TEXT NOT NULL,
        numeroSalle INTEGER NOT NULL,
        capacite INTEGER NOT NULL,
        placesLibres INTEGER NOT NULL,
        typeExamen TEXT NOT NULL,
        anneeSession INTEGER NOT NULL
      )
    ''');

    // --- Attribution d'un quota de candidats par établissement, pour
    // chaque salle partagée d'un centre d'écrit ---
    await db.execute('''
      CREATE TABLE $tableAttributionSalle (
        id TEXT PRIMARY KEY,
        codeSalle TEXT NOT NULL,
        codeEtab TEXT NOT NULL,
        nombreCandidats INTEGER NOT NULL
      )
    ''');

    // --- Période de saisie autorisée, définie par l'admin, visible par
    // tous les établissements (une seule ligne, id fixe 'global') ---
    await db.execute('''
      CREATE TABLE $tablePeriodeSaisie (
        id TEXT PRIMARY KEY,
        dateDebut TEXT NOT NULL,
        dateFin TEXT NOT NULL,
        description TEXT NOT NULL,
        definiLe TEXT NOT NULL
      )
    ''');

    // --- Table générique pour toutes les listes de référence modifiables ---
    await db.execute('''
      CREATE TABLE $tableItemListe (
        id TEXT PRIMARY KEY,
        typeListe TEXT NOT NULL,
        champs TEXT NOT NULL
      )
    ''');

    // --- Table Enseignant (par établissement) ---
    await db.execute('''
      CREATE TABLE $tableEnseignant (
        matricule TEXT PRIMARY KEY,
        nom TEXT NOT NULL,
        prenom TEXT NOT NULL,
        phone TEXT NOT NULL,
        adresse TEXT NOT NULL,
        codeEtab TEXT NOT NULL,
        fonction TEXT NOT NULL,
        cin TEXT,
        sexe TEXT
      )
    ''');

    // --- Table Quota (nombre voulu par rôle, par établissement/année) ---
    await db.execute('''
      CREATE TABLE $tableQuotaMembre (
        id TEXT PRIMARY KEY,
        codeEtab TEXT NOT NULL,
        anneeSession INTEGER NOT NULL,
        role TEXT NOT NULL,
        quantite INTEGER NOT NULL,
        typeExamen TEXT NOT NULL DEFAULT 'CEPE'
      )
    ''');

    // --- Table Chat (messages établissement <-> Administration CISCO) ---
    // Version LOCALE pour tester sur Windows sans Firebase. Même structure
    // que la future collection Firestore, pour faciliter le passage à la
    // vraie synchro en ligne plus tard.
    await db.execute('''
      CREATE TABLE $tableChatMessage (
        id TEXT PRIMARY KEY,
        codeEtab TEXT NOT NULL,
        expediteur TEXT NOT NULL,
        texte TEXT NOT NULL,
        horodatage TEXT NOT NULL,
        lu INTEGER NOT NULL DEFAULT 0,
        photoPath TEXT,
        modifie INTEGER NOT NULL DEFAULT 0
      )
    ''');
  }

  // ======================================================================
  //  CEPE
  // ======================================================================

  Future<void> insererCandidatCepe(CandidatCepe candidat) async {
    final db = await database;
    await db.insert(
      tableCandidatCepe,
      candidat.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<CandidatCepe>> listerCandidatsCepe({int? anneeSession}) async {
    final db = await database;
    final List<Map<String, Object?>> rows = anneeSession == null
        ? await db.query(tableCandidatCepe)
        : await db.query(
            tableCandidatCepe,
            where: 'anneeSession = ?',
            whereArgs: [anneeSession],
          );
    return rows.map(CandidatCepe.fromMap).toList();
  }

  Future<CandidatCepe?> lireCandidatCepe(String codeCandidat) async {
    final db = await database;
    final rows = await db.query(
      tableCandidatCepe,
      where: 'codeCandidat = ?',
      whereArgs: [codeCandidat],
    );
    if (rows.isEmpty) return null;
    return CandidatCepe.fromMap(rows.first);
  }

  Future<void> modifierCandidatCepe(CandidatCepe candidat) async {
    final db = await database;
    await db.update(
      tableCandidatCepe,
      candidat.toMap(),
      where: 'codeCandidat = ?',
      whereArgs: [candidat.codeCandidat],
    );
  }

  Future<void> supprimerCandidatCepe(String codeCandidat) async {
    final db = await database;
    await db.delete(
      tableCandidatCepe,
      where: 'codeCandidat = ?',
      whereArgs: [codeCandidat],
    );
  }

  // ======================================================================
  //  BEPC
  // ======================================================================

  Future<void> insererCandidatBepc(CandidatBepc candidat) async {
    final db = await database;
    await db.insert(
      tableCandidatBepc,
      candidat.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<CandidatBepc>> listerCandidatsBepc({int? anneeSession}) async {
    final db = await database;
    final List<Map<String, Object?>> rows = anneeSession == null
        ? await db.query(tableCandidatBepc)
        : await db.query(
            tableCandidatBepc,
            where: 'anneeSession = ?',
            whereArgs: [anneeSession],
          );
    return rows.map(CandidatBepc.fromMap).toList();
  }

  Future<CandidatBepc?> lireCandidatBepc(String codeCandidat) async {
    final db = await database;
    final rows = await db.query(
      tableCandidatBepc,
      where: 'codeCandidat = ?',
      whereArgs: [codeCandidat],
    );
    if (rows.isEmpty) return null;
    return CandidatBepc.fromMap(rows.first);
  }

  Future<void> modifierCandidatBepc(CandidatBepc candidat) async {
    final db = await database;
    await db.update(
      tableCandidatBepc,
      candidat.toMap(),
      where: 'codeCandidat = ?',
      whereArgs: [candidat.codeCandidat],
    );
  }

  Future<void> supprimerCandidatBepc(String codeCandidat) async {
    final db = await database;
    await db.delete(
      tableCandidatBepc,
      where: 'codeCandidat = ?',
      whereArgs: [codeCandidat],
    );
  }

  // ======================================================================
  //  MembrePrevisionnel (jury, correcteur, chef de centre, sécurité)
  // ======================================================================

  Future<void> insererMembre(MembrePrevisionnel membre) async {
    final db = await database;
    await db.insert(
      tableMembrePrevisionnel,
      membre.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<MembrePrevisionnel>> listerMembres({
    int? anneeSession,
    String? role,
    String? typeExamen,
  }) async {
    final db = await database;
    final List<String> conditions = [];
    final List<Object?> args = [];
    if (anneeSession != null) {
      conditions.add('anneeSession = ?');
      args.add(anneeSession);
    }
    if (role != null) {
      conditions.add('role = ?');
      args.add(role);
    }
    if (typeExamen != null) {
      conditions.add('typeExamen = ?');
      args.add(typeExamen);
    }
    final rows = await db.query(
      tableMembrePrevisionnel,
      where: conditions.isEmpty ? null : conditions.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
    );
    return rows.map(MembrePrevisionnel.fromMap).toList();
  }

  Future<MembrePrevisionnel?> lireMembre(String codeMembre) async {
    final db = await database;
    final rows = await db.query(
      tableMembrePrevisionnel,
      where: 'codeMembre = ?',
      whereArgs: [codeMembre],
    );
    if (rows.isEmpty) return null;
    return MembrePrevisionnel.fromMap(rows.first);
  }

  Future<void> modifierMembre(MembrePrevisionnel membre) async {
    final db = await database;
    await db.update(
      tableMembrePrevisionnel,
      membre.toMap(),
      where: 'codeMembre = ?',
      whereArgs: [membre.codeMembre],
    );
  }

  Future<void> supprimerMembre(String codeMembre) async {
    final db = await database;
    await db.delete(
      tableMembrePrevisionnel,
      where: 'codeMembre = ?',
      whereArgs: [codeMembre],
    );
  }

  /// Étape "s'identifier" : enregistre les photos CIN et fait passer
  /// l'état de Désigné → Identifié (avant vérification par le système).
  Future<void> identifierMembre({
    required String codeMembre,
    required String photoCinRecto,
    required String photoCinVerso,
  }) async {
    final membre = await lireMembre(codeMembre);
    if (membre == null) return;
    await modifierMembre(
      membre.copyWith(
        etat: 'Identifié',
        photoCinRecto: photoCinRecto,
        photoCinVerso: photoCinVerso,
      ),
    );
  }

  /// Étape "placer le membre par centre" : appelée seulement si
  /// l'identité est validée (voir diagramme de séquence — alt [identité valide]).
  Future<void> placerMembreEnPoste({
    required String codeMembre,
    String? codeCentreEcrit,
    String? codeCentreCorrection,
  }) async {
    final membre = await lireMembre(codeMembre);
    if (membre == null) return;
    await modifierMembre(
      membre.copyWith(
        etat: 'En poste',
        codeCentreEcrit: codeCentreEcrit,
        codeCentreCorrection: codeCentreCorrection,
      ),
    );
  }

  /// Étape "confirmer présent/absent" le jour de l'examen.
  Future<void> confirmerPresenceMembre({
    required String codeMembre,
    required bool present,
  }) async {
    final membre = await lireMembre(codeMembre);
    if (membre == null) return;
    await modifierMembre(membre.copyWith(etat: present ? 'Présent' : 'Absent'));
  }

  // ======================================================================
  //  Salle (saisie manuelle par centre)
  // ======================================================================

  Future<void> insererSalle(Salle salle) async {
    final db = await database;
    await db.insert(
      tableSalle,
      salle.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Salle>> listerSalles({
    required String typeExamen,
    String? codeCentre,
    int? anneeSession,
  }) async {
    final db = await database;
    final List<String> conditions = ['typeExamen = ?'];
    final List<Object?> args = [typeExamen];
    if (codeCentre != null) {
      conditions.add('codeCentre = ?');
      args.add(codeCentre);
    }
    if (anneeSession != null) {
      conditions.add('anneeSession = ?');
      args.add(anneeSession);
    }
    final rows = await db.query(
      tableSalle,
      where: conditions.join(' AND '),
      whereArgs: args,
    );
    return rows.map(Salle.fromMap).toList();
  }

  Future<void> modifierSalle(Salle salle) async {
    final db = await database;
    await db.update(
      tableSalle,
      salle.toMap(),
      where: 'id = ?',
      whereArgs: [salle.id],
    );
  }

  Future<void> supprimerSalle(String id) async {
    final db = await database;
    await db.delete(tableSalle, where: 'id = ?', whereArgs: [id]);
    // Nettoyage en cascade : les attributions des établissements dans
    // cette salle n'ont plus de sens si la salle n'existe plus.
    await db.delete(
      tableAttributionSalle,
      where: 'codeSalle = ?',
      whereArgs: [id],
    );
  }

  // ======================================================================
  //  ItemListe (générique : établissement, école d'origine, CEG/lycée
  //  d'accueil, langue, sport... — tout ce qui est ajoutable via le "+")
  // ======================================================================

  Future<void> insererItemListe(ItemListe item) async {
    final db = await database;
    await db.insert(
      tableItemListe,
      item.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<ItemListe>> listerItems(String typeListe) async {
    final db = await database;
    final rows = await db.query(
      tableItemListe,
      where: 'typeListe = ?',
      whereArgs: [typeListe],
    );
    return rows.map(ItemListe.fromMap).toList();
  }

  Future<void> modifierItemListe(ItemListe item) async {
    final db = await database;
    await db.update(
      tableItemListe,
      item.toMap(),
      where: 'id = ?',
      whereArgs: [item.id],
    );
  }

  Future<void> supprimerItemListe(String id) async {
    final db = await database;
    await db.delete(tableItemListe, where: 'id = ?', whereArgs: [id]);
  }

  // ======================================================================
  //  Enseignant (par établissement)
  // ======================================================================

  Future<void> insererEnseignant(Enseignant enseignant) async {
    final db = await database;
    await db.insert(
      tableEnseignant,
      enseignant.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Enseignant>> listerEnseignants(String codeEtab) async {
    final db = await database;
    final rows = await db.query(
      tableEnseignant,
      where: 'codeEtab = ?',
      whereArgs: [codeEtab],
    );
    return rows.map(Enseignant.fromMap).toList();
  }

  /// Tous les enseignants, tous établissements confondus — utilisé côté
  /// Administration CISCO pour les statistiques globales.
  Future<List<Enseignant>> listerTousEnseignants() async {
    final db = await database;
    final rows = await db.query(tableEnseignant);
    return rows.map(Enseignant.fromMap).toList();
  }

  Future<void> modifierEnseignant(Enseignant enseignant) async {
    final db = await database;
    await db.update(
      tableEnseignant,
      enseignant.toMap(),
      where: 'matricule = ?',
      whereArgs: [enseignant.matricule],
    );
  }

  Future<void> supprimerEnseignant(String matricule) async {
    final db = await database;
    await db.delete(
      tableEnseignant,
      where: 'matricule = ?',
      whereArgs: [matricule],
    );
  }

  // ======================================================================
  //  QuotaMembre (nombre voulu par rôle, par établissement + année)
  // ======================================================================

  Future<void> definirQuota(QuotaMembre quota) async {
    final db = await database;
    await db.insert(
      tableQuotaMembre,
      quota.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<QuotaMembre>> listerQuotas({
    required String codeEtab,
    required int anneeSession,
    String? typeExamen,
  }) async {
    final db = await database;
    final conditions = ['codeEtab = ?', 'anneeSession = ?'];
    final args = <Object?>[codeEtab, anneeSession];
    if (typeExamen != null) {
      conditions.add('typeExamen = ?');
      args.add(typeExamen);
    }
    final rows = await db.query(
      tableQuotaMembre,
      where: conditions.join(' AND '),
      whereArgs: args,
    );
    return rows.map(QuotaMembre.fromMap).toList();
  }

  // ======================================================================
  //  AttributionSalle (quota de candidats par établissement, par salle)
  // ======================================================================

  Future<void> definirAttributionSalle(AttributionSalle attribution) async {
    final db = await database;
    await db.insert(
      tableAttributionSalle,
      attribution.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<AttributionSalle>> listerAttributionsSalle(
    String codeSalle,
  ) async {
    final db = await database;
    final rows = await db.query(
      tableAttributionSalle,
      where: 'codeSalle = ?',
      whereArgs: [codeSalle],
    );
    return rows.map(AttributionSalle.fromMap).toList();
  }

  /// L'attribution d'un établissement donné dans une salle donnée (ou
  /// null s'il n'a encore rien réservé dans cette salle).
  Future<AttributionSalle?> lireAttributionSalle(
    String codeSalle,
    String codeEtab,
  ) async {
    final db = await database;
    final rows = await db.query(
      tableAttributionSalle,
      where: 'codeSalle = ? AND codeEtab = ?',
      whereArgs: [codeSalle, codeEtab],
    );
    if (rows.isEmpty) return null;
    return AttributionSalle.fromMap(rows.first);
  }

  Future<void> supprimerAttributionSalle(String id) async {
    final db = await database;
    await db.delete(tableAttributionSalle, where: 'id = ?', whereArgs: [id]);
  }

  // ======================================================================
  //  PeriodeSaisie (fenêtre de saisie autorisée, définie par l'admin)
  // ======================================================================

  Future<void> definirPeriodeSaisie(PeriodeSaisie periode) async {
    final db = await database;
    await db.insert(
      tablePeriodeSaisie,
      periode.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<PeriodeSaisie?> lirePeriodeSaisie() async {
    final db = await database;
    final rows = await db.query(
      tablePeriodeSaisie,
      where: 'id = ?',
      whereArgs: [PeriodeSaisie.idGlobal],
    );
    if (rows.isEmpty) return null;
    return PeriodeSaisie.fromMap(rows.first);
  }

  // ======================================================================
  //  Chat (établissement <-> Administration CISCO) — version locale
  // ======================================================================

  Future<void> insererMessageChat(ChatMessage message, String codeEtab) async {
    final db = await database;
    final donnees = message.toMap();
    donnees['codeEtab'] = codeEtab;
    await db.insert(
      tableChatMessage,
      donnees,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<ChatMessage>> listerMessagesChat(String codeEtab) async {
    final db = await database;
    final rows = await db.query(
      tableChatMessage,
      where: 'codeEtab = ?',
      whereArgs: [codeEtab],
      orderBy: 'horodatage ASC',
    );
    return rows.map(ChatMessage.fromMap).toList();
  }

  /// Modifie le texte d'un message existant (marque `modifie = 1`).
  Future<void> modifierMessageChat(String id, String nouveauTexte) async {
    final db = await database;
    await db.update(
      tableChatMessage,
      {'texte': nouveauTexte, 'modifie': 1},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  /// Supprime définitivement un message.
  Future<void> supprimerMessageChat(String id) async {
    final db = await database;
    await db.delete(tableChatMessage, where: 'id = ?', whereArgs: [id]);
  }

  /// Nombre de messages non lus dans une conversation, envoyés par
  /// quelqu'un d'autre que [expediteur] (utilisé pour la pastille de
  /// notification).
  Future<int> compterMessagesNonLus(
    String codeEtab, {
    required String saufExpediteur,
  }) async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT COUNT(*) AS n FROM $tableChatMessage '
      'WHERE codeEtab = ? AND lu = 0 AND expediteur != ?',
      [codeEtab, saufExpediteur],
    );
    return (result.first['n'] as int?) ?? 0;
  }

  /// Marque tous les messages d'une conversation comme lus (sauf ceux
  /// envoyés par [saufExpediteur], qui n'ont pas besoin de l'être).
  Future<void> marquerMessagesLus(
    String codeEtab, {
    required String saufExpediteur,
  }) async {
    final db = await database;
    await db.update(
      tableChatMessage,
      {'lu': 1},
      where: 'codeEtab = ? AND expediteur != ?',
      whereArgs: [codeEtab, saufExpediteur],
    );
  }

  /// Liste des établissements ayant au moins un message, avec le dernier
  /// message de chacun — utilisé côté admin pour la liste des conversations.
  Future<List<Map<String, Object?>>> listerConversationsChat() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT codeEtab, texte AS dernierMessage, expediteur AS dernierExpediteur, MAX(horodatage) AS derniereActivite
      FROM $tableChatMessage
      GROUP BY codeEtab
      ORDER BY derniereActivite DESC
    ''');
    return rows;
  }

  // ======================================================================
  //  Utilitaires communs (utile pour l'archivage / clôture de session)
  // ======================================================================

  /// Supprime toutes les données d'une année de session donnée, dans les
  /// deux tables. Utilisé par archive_service.dart après export en .zip.
  Future<void> supprimerSession(int anneeSession) async {
    final db = await database;
    await db.delete(
      tableCandidatCepe,
      where: 'anneeSession = ?',
      whereArgs: [anneeSession],
    );
    await db.delete(
      tableCandidatBepc,
      where: 'anneeSession = ?',
      whereArgs: [anneeSession],
    );
    await db.delete(
      tableMembrePrevisionnel,
      where: 'anneeSession = ?',
      whereArgs: [anneeSession],
    );
    await db.delete(
      tableSalle,
      where: 'anneeSession = ?',
      whereArgs: [anneeSession],
    );
  }
}
